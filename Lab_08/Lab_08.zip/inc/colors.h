#ifndef COLORS_H
#define COLORS_H

#define res "\033[0m"
#define red "\033[31m"
#define gr "\033[32m"
#define yel "\033[33m"
#define blue "\033[34m"
#define cy "\033[36m"

#define del "\33[2K\033[A\r\33[2K"

#endif

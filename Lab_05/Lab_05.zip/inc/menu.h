#ifndef MENU_H
#define MENU_H

#include "../inc/structs.h"

void array_queue_menu();
int input_number(int *num);
void node_queue_menu();

#endif

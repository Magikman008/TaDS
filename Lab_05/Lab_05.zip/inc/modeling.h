#ifndef MODELING_H
#define MODELING_H

#include "../inc/structs.h"

void model_node_queue();
void model_array_queue();

#endif

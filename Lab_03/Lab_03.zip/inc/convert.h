#ifndef CONVERT_H
#define CONVERT_H

#include "../inc/structs.h"

void conver_to_normal_matrix(matrix_t *matrix, sparce_matrix_t *smatrix);
void conver_to_normal_vector(vector_t *vector, sparce_vector_t *svector);

#endif

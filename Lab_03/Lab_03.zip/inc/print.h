#ifndef PRINT_H
#define PRINT_H

#include "../inc/structs.h"
void print_sparce_vector(sparce_vector_t *vector);
void print_sparce_matrix(sparce_matrix_t *matrix);
void print_matrix(matrix_t *matrix);
void print_vector(vector_t *vector);

#endif

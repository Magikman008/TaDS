#ifndef MULT_H
#define MULT_H

#include "../inc/structs.h"

void make_sparce_answer(sparce_matrix_t *matrix, sparce_vector_t *vector, sparce_vector_t *vector_std);
void make_answer(matrix_t *matrix, vector_t *vector, vector_t *vector_std);

#endif

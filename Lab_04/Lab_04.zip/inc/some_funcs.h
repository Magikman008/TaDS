#ifndef SOME_F_H
#define SOME_F_H

#include "../inc/structs.h"

int input(char *c);
int check_array_stack();
int check_node_stack();

#endif

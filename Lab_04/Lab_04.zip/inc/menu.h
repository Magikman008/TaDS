#ifndef MENU_H
#define MENU_H

#include "../inc/structs.h"

void array_stack_menu();
void node_stack_menu();
int input_number(int *num);

#endif
